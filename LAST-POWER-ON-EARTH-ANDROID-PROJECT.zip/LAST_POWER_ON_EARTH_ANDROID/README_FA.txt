پروژه اندرویدی بازی «آخرین قدرت زمین»

این پوشه پروژه Android Studio است و فایل اصلی بازی در مسیر زیر قرار دارد:
app/src/main/assets/index.html

برای ساخت APK:
1) Android Studio را نصب و این پوشه را با گزینه Open باز کنید.
2) صبر کنید Gradle Sync کامل شود و Android SDK 35 نصب باشد.
3) از منوی Build گزینه Build Bundle(s) / APK(s) و سپس Build APK(s) را انتخاب کنید.
4) فایل خروجی معمولاً در مسیر app/build/outputs/apk/debug/app-debug.apk قرار می‌گیرد.

برای انتشار عمومی در فروشگاه‌ها باید نسخه Release را با کلید امضای اختصاصی خودتان بسازید.
